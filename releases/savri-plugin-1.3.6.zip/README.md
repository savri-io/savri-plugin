# Savri analytics plugin

Version 1.3.6 offers optional, brief help with traffic, visitor sources and popular pages. Ask a normal question to begin. A site that already receives visits leads to reports, including after payment or handover. Installation and code are explained only when requested; otherwise help can be passed to the website maintainer. Requires hosted server 1.3.4 or later.

## Advertising reports

When the connection exposes `savri_get_ads_report`, it can read saved campaign costs, clicks and matched website goals. This is a restricted reporting pilot: the site needs a separate report grant and approved campaign connections. Reports cover up to 31 account-local days, mark partial totals and retain missing values. Form events are not unique leads, verified sales or Google-reported conversions. It cannot read search terms, ads or bids, change campaigns, or upload conversions.

![Savri](assets/icon.png)

Connect your own [Savri](https://savri.io) account and ask about visitors, traffic sources, top pages, countries, goals, funnels, and registered event properties.

This [Agent Plugin](https://agent-plugins.org) packages Savri's hosted MCP connection and a web analytics skill. It runs no local server and contains no credentials. Cursor supports the Agent Plugins format. Marketplace approval and end-to-end Grok Bot compatibility are separate checks; this source repository does not imply a published marketplace listing.

## Evidence handling (1.3.2)

This skill update adds a compact source table and explicit final-answer checks
for periods, commission qualifications and unsupported causes. Search clicks
cannot bound the cause of a visit change without linked measurements, and page
visits do not establish purchase intent. It retains the earlier rules for
unknown business types and repeated genuine clicks. These instructions guide
the model but do not guarantee every free-form conclusion; check the evidence
before changing measurement or business priorities.
This release pairs hosted server 1.3.4 with npm 0.6.4.

## Portfolio, affiliate and alerts (1.3.0)

This package keeps the existing plugin identity and uses Value Unlimited
as publisher. It is not evidence of a released directory update. Its skill covers
explicit selections across authorized sites, saved business context, affiliate
commission/matching/coverage and requested alert previews or changes. A domain,
sales objective or platform alone does not classify a site as merchant e-commerce.

This release exposes 37 tools through remote 1.3.4 and npm 0.6.4, including
`savri_get_ads_report`, `savri_get_affiliate_report` and
`savri_get_alerts`, `savri_preview_alert`, `savri_save_alert`,
`savri_disable_alert`, `savri_delete_alert`. Discover actual installed tools;
missing tools mean unavailable client functionality, not zero activity.

`savri_get_stats` accepts optional `completed_days:true` for exact completed UTC
days, equal previous periods and explicit coverage. Missing aggregate dates and
zero-baseline percentages remain unknown; server 1.3.0 also uses completed dates for old stats calls while retaining their response format.
Google/Bing and page/source reports keep their own dates. Affiliate figures use
the report's display decimals and separate currencies, statuses and match classes.
An analysis never activates alerts or saves a profile. Activation requires the
recipient's own consent, edit/write rights and the site's payer entitlement.

The canonical skill also supplies the Claude adapter. Its package, the hosted
server, directory discovery and actual installed-client verification are distinct
release steps. This package requires hosted server 1.3.0 or later.

## Guided start (previous 1.2.1)

Version 1.2.1 preserves the existing OpenAI package identity and verified
publisher when uploading to the same Savri directory entry. The portable
Agent Plugin format, hosted endpoint and analytics workflow are unchanged.

Adds `savri_get_setup_status`, `savri_save_business_profile` and
`savri_record_start_feedback` (30 remote tools in total). The shared status
service distinguishes connection/configuration from observed measurement and
controlled tests. Event/page/crawler results are bounded samples with explicit
limits. Google/Bing report checks are requested only when needed; Bing remains
personal to the signed-in user.

The starter prompts offer examples; a normal question is enough. Start help is optional and does not begin an installation questionnaire.
The skill continues to a supported business answer and a draft in the host chat
when requested. Saving business context requires an explicit request and site
editor/owner plus client write permission. Analysis does not save profiles or
create goals. Feedback records the user's explicit answer, never inferred success.

`extensions.com.openai.interface.defaultPrompt` and `onboardingSkill` follow
the [OpenAI submission format](https://developers.openai.com/plugins/deploy/submission).
The portable manifest and MCP endpoint alone do not update the released ChatGPT
catalog package. Server release, package distribution/review, directory tool
refresh and an installed-client test are separate steps. This package requires
remote 1.2.0 or later. No automatic conversation on installation
is promised. [First question and agency handover](https://savri.io/docs/connectors/chatgpt#first-answer).

## Existing search reports

Remote MCP 1.1.0 introduced eight read-only Google/Bing reports, also included in 1.2.0. Package distribution and each directory's discovery/review are separate steps. Check the tools exposed by your installed client; this repository does not establish marketplace availability.

Connect Google Search Console or Bing Webmaster Tools in the site dashboard from Basic. Google uses the site's shared connection; Bing uses your own connection per site. The hosted OAuth connection needs no API key. The separate local `@savri/mcp` package requires an account API key and API access from Growth.

Search tools are `savri_get_gsc_overview`, `savri_get_gsc_queries`, `savri_get_gsc_pages`, `savri_get_gsc_trend`, `savri_get_bing_overview`, `savri_get_bing_queries`, `savri_get_bing_pages`, and `savri_get_bing_trend`. Check which tools your client actually exposes. If these are missing, use the dashboard; do not infer an empty report.

- Google uses final days in Pacific Time, exact page/query filters, optional country/device and equal-length comparisons. Limited candidate rows are not a complete query history; missing values remain unknown.
- Bing daily traffic and weekly Web query/page reports have different coverage. Select returned report dates without inventing week boundaries. Country/device filters are unsupported.
- These reports do not link a query to a person or order and do not provide separate AI citation counts. Keep sources and periods separate.

Guides: [Google](https://savri.io/docs/gsc), [Bing](https://savri.io/docs/bing), [API contract](https://savri.io/docs/public-api#search-reports).

## Requirements

- A Savri account with access to the website you want to analyze.
- Collected analytics for questions about your traffic. Install the [tracking script](https://savri.io/docs/integration-guides) first if needed.
- A client supporting Agent Plugins, Streamable HTTP MCP and client-managed OAuth. Workspace policies may restrict custom plugins.

## Connect

Install this package using your client's supported plugin workflow. The MCP server is:

```text
https://savri.io/api/mcp
```

When the client starts authentication, sign in to Savri in your browser and review the requested permissions. Never paste your password or access token into chat. Client-specific setup and availability are documented in [Savri's connector guides](https://savri.io/docs/connectors).

For manual Cursor MCP setup, add the following entry to your existing `mcpServers` object without replacing other servers:

```json
{
  "savri": {
    "url": "https://savri.io/api/mcp"
  }
}
```

That manual entry connects the server; it does not install the packaged skill. Restart or refresh the client's MCP connection, then complete OAuth when prompted. The actual callback must be accepted by Savri; a working desktop connection does not prove compatibility with every cloud client.

## Try it

- "Which of my sites can you access through Savri?"
- "Compare visitors to example.com over the last 7 days with the previous period."
- "Which pages and traffic sources brought the most visitors?"
- "Review the existing goals and funnels for example.com."
- "Show Google queries for example.com over the last seven final days, then show Bing’s latest weekly queries separately with actual coverage."

The skill selects real site IDs, preserves source dates, distinguishes observations from explanations, and avoids treating outbound clicks as purchases. Prefer completed `7d`, `30d`, or `90d` when the installed schema exposes that option. Older servers can retain rolling periods; follow the dates actually returned. Google and Bing use the separate date contracts above.

## Permissions and data

OAuth controls access to your own authorized sites. The server supports read and write scopes. It can also create, rename, or delete supported resources when write access is granted; the analytics skill uses read tools for reporting. Skill instructions are not a security boundary.

Tool results are sent to the AI client you choose. Review that client's data settings and [Savri's privacy policy](https://savri.io/privacy). Each user authenticates separately; sharing the plugin does not share your account or data. Disconnect through your AI client's integration settings when you no longer need access.

## Optional Grok Bot profile

[Savri Analytics Analyst](bots/analytics-analyst.md) provides a suggested name and profile for a bot that uses this plugin. Create it only after verifying the connection in Grok Bot. It schedules nothing by default and contains no customer-specific data. Sharing a bot template does not automatically list it in the public Bot Marketplace.

## Package and maintenance

- `plugin.json`: portable manifest.
- `mcp.json`: hosted server definition.
- `skills/web-analytics/SKILL.md`: reporting workflow and interpretation rules.
- `bots/analytics-analyst.md`: optional bot profile.

Source files are maintained by the Savri team and distributed here. This package is MIT licensed; using the hosted service is governed by [Savri's terms](https://savri.io/terms). For support, contact [hello@savri.io](mailto:hello@savri.io).
